"""
SDF-Based Soft Rasterization Placer — v5

Back to v2 approach (best so far: 1.5062 avg on --all).
Changes: tune density threshold, add more iterations, adjust overlap timing.
Goal: reduce density and congestion while maintaining low WL.

Used as the initial pass for every CD-based placer (see
``macro_place.cd_core.sdf_init`` for the thin wrapper used by placers).
"""

import math
import random

import numpy as np
import torch

from macro_place.benchmark import Benchmark
from .bench_paths import find_benchmark_dir
from .runtime_safety import finalize_placement
from macro_place.loader import load_benchmark_from_dir


def _load_plc(name):
    try:
        root = find_benchmark_dir(name)
    except FileNotFoundError:
        return None
    _, plc = load_benchmark_from_dir(str(root))
    return plc


def _extract_edges(benchmark, plc):
    name_to_bidx = {}
    for bidx, idx in enumerate(benchmark.hard_macro_indices):
        name_to_bidx[plc.modules_w_pins[idx].get_name()] = bidx
    pin_to_bidx = {}
    for pin_idx in plc.hard_macro_pin_indices:
        pin = plc.modules_w_pins[pin_idx]
        parent_bidx = name_to_bidx.get(pin.get_macro_name())
        if parent_bidx is not None:
            pin_to_bidx[pin.get_name()] = parent_bidx
    edge_dict = {}
    for driver, sinks in plc.nets.items():
        macros = set()
        for pin_name in [driver] + sinks:
            bidx = pin_to_bidx.get(pin_name)
            if bidx is not None:
                macros.add(bidx)
        if len(macros) >= 2:
            ml = sorted(macros)
            w = 1.0 / (len(ml) - 1)
            for i in range(len(ml)):
                for j in range(i + 1, len(ml)):
                    pair = (ml[i], ml[j])
                    edge_dict[pair] = edge_dict.get(pair, 0) + w
    if not edge_dict:
        return torch.zeros(0, 2, dtype=torch.long), torch.zeros(0)
    edges = list(edge_dict.keys())
    return (torch.tensor(edges, dtype=torch.long),
            torch.tensor([edge_dict[e] for e in edges], dtype=torch.float32))


def sdf_density_grid(pos, half_sizes, grid_x, grid_y, tau):
    N = pos.shape[0]
    gx = grid_x.unsqueeze(0)
    gy = grid_y.unsqueeze(1)
    density = torch.zeros(len(grid_y), len(grid_x), device=pos.device)
    chunk_size = 128
    for start in range(0, N, chunk_size):
        end = min(start + chunk_size, N)
        cx = pos[start:end, 0].reshape(-1, 1, 1)
        cy = pos[start:end, 1].reshape(-1, 1, 1)
        hw = half_sizes[start:end, 0].reshape(-1, 1, 1)
        hh = half_sizes[start:end, 1].reshape(-1, 1, 1)
        dx = torch.abs(gx.unsqueeze(0) - cx) - hw
        dy = torch.abs(gy.unsqueeze(0) - cy) - hh
        occ = torch.sigmoid(-dx / tau) * torch.sigmoid(-dy / tau)
        density = density + occ.sum(dim=0)
    return density


def edge_wl(pos, edges, edge_weights):
    if len(edges) == 0:
        return torch.tensor(0.0, device=pos.device)
    src = pos[edges[:, 0]]
    dst = pos[edges[:, 1]]
    dist = torch.abs(src - dst).sum(dim=1)
    return (edge_weights * dist).sum()


def overlap_penalty(pos, half_sizes):
    N = pos.shape[0]
    if N < 2:
        return torch.tensor(0.0, device=pos.device)
    dx = torch.abs(pos[:, 0].unsqueeze(1) - pos[:, 0].unsqueeze(0))
    dy = torch.abs(pos[:, 1].unsqueeze(1) - pos[:, 1].unsqueeze(0))
    sep_x = half_sizes[:, 0].unsqueeze(1) + half_sizes[:, 0].unsqueeze(0)
    sep_y = half_sizes[:, 1].unsqueeze(1) + half_sizes[:, 1].unsqueeze(0)
    overlap_area = torch.relu(sep_x - dx) * torch.relu(sep_y - dy)
    mask = torch.triu(torch.ones(N, N, device=pos.device, dtype=torch.bool), diagonal=1)
    return (overlap_area * mask).sum()


def greedy_legalize(pos_np, sizes_np, movable, canvas_w, canvas_h):
    n = len(pos_np)
    half_w = sizes_np[:, 0] / 2
    half_h = sizes_np[:, 1] / 2
    sep_x = (sizes_np[:, 0:1] + sizes_np[:, 0:1].T) / 2
    sep_y = (sizes_np[:, 1:2] + sizes_np[:, 1:2].T) / 2
    order = sorted(range(n), key=lambda i: -sizes_np[i, 0] * sizes_np[i, 1])
    placed = ~np.asarray(movable, dtype=bool)
    legal = pos_np.copy()
    for idx in order:
        if not movable[idx]:
            placed[idx] = True
            continue
        if placed.any():
            dx_arr = np.abs(legal[idx, 0] - legal[:, 0])
            dy_arr = np.abs(legal[idx, 1] - legal[:, 1])
            c = (dx_arr < sep_x[idx] + 0.05) & (dy_arr < sep_y[idx] + 0.05) & placed
            c[idx] = False
            if not c.any():
                placed[idx] = True
                continue
        step = max(sizes_np[idx, 0], sizes_np[idx, 1]) * 0.2
        best_p = legal[idx].copy()
        best_d = float('inf')
        for r in range(1, 250):
            found = False
            for dxm in range(-r, r + 1):
                for dym in range(-r, r + 1):
                    if abs(dxm) != r and abs(dym) != r:
                        continue
                    cx = np.clip(pos_np[idx, 0] + dxm * step, half_w[idx], canvas_w - half_w[idx])
                    cy = np.clip(pos_np[idx, 1] + dym * step, half_h[idx], canvas_h - half_h[idx])
                    if placed.any():
                        dx_arr = np.abs(cx - legal[:, 0])
                        dy_arr = np.abs(cy - legal[:, 1])
                        c = (dx_arr < sep_x[idx] + 0.05) & (dy_arr < sep_y[idx] + 0.05) & placed
                        c[idx] = False
                        if c.any():
                            continue
                    d = (cx - pos_np[idx, 0]) ** 2 + (cy - pos_np[idx, 1]) ** 2
                    if d < best_d:
                        best_d = d
                        best_p = np.array([cx, cy])
                        found = True
            if found:
                break
        legal[idx] = best_p
        placed[idx] = True
    return legal


class SDFPlacer:
    """SDF-based analytical placer v5 — tuned from v2."""

    def __init__(self, seed=42, n_iters=500, lr=3.0,
                 density_weight=0.4, overlap_weight=80.0,
                 grid_resolution=32):
        self.seed = seed
        self.n_iters = n_iters
        self.lr = lr
        self.density_weight = density_weight
        self.overlap_weight = overlap_weight
        self.grid_resolution = grid_resolution

    def place(self, benchmark: Benchmark) -> torch.Tensor:
        torch.manual_seed(self.seed)
        random.seed(self.seed)
        np.random.seed(self.seed)

        n_hard = benchmark.num_hard_macros
        cw = float(benchmark.canvas_width)
        ch = float(benchmark.canvas_height)
        sizes = benchmark.macro_sizes[:n_hard].clone()
        half_sizes = sizes / 2
        movable = benchmark.get_movable_mask()[:n_hard]

        plc = _load_plc(benchmark.name)
        if plc is not None:
            edges, edge_weights = _extract_edges(benchmark, plc)
        else:
            edges = torch.zeros(0, 2, dtype=torch.long)
            edge_weights = torch.zeros(0)

        canvas_diag = math.sqrt(cw ** 2 + ch ** 2)
        tau_start = canvas_diag * 0.05
        tau_end = canvas_diag * 0.002

        grid_res = self.grid_resolution
        grid_x = torch.linspace(0, cw, grid_res)
        grid_y = torch.linspace(0, ch, grid_res)

        total_macro_area = (sizes[:, 0] * sizes[:, 1]).sum().item()
        uniform_density = total_macro_area / (cw * ch)

        init_pos = benchmark.macro_positions[:n_hard].clone()
        init_pos[:, 0] = init_pos[:, 0].clamp(half_sizes[:, 0], cw - half_sizes[:, 0])
        init_pos[:, 1] = init_pos[:, 1].clamp(half_sizes[:, 1], ch - half_sizes[:, 1])

        with torch.no_grad():
            wl0 = edge_wl(init_pos, edges, edge_weights)
            wl_norm = max(wl0.item(), 1e-6)

        pos = init_pos.clone().detach().requires_grad_(True)
        optimizer = torch.optim.Adam([pos], lr=self.lr)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, self.n_iters, eta_min=self.lr * 0.03)

        best_pos = init_pos.clone()
        best_cost = float('inf')

        for step in range(self.n_iters):
            optimizer.zero_grad()
            frac = step / max(self.n_iters - 1, 1)
            tau = tau_start * (tau_end / tau_start) ** frac

            current_pos = torch.where(movable.unsqueeze(1).expand_as(pos), pos, init_pos)
            clamped = torch.stack([
                current_pos[:, 0].clamp(half_sizes[:, 0], cw - half_sizes[:, 0]),
                current_pos[:, 1].clamp(half_sizes[:, 1], ch - half_sizes[:, 1]),
            ], dim=1)

            # Density: use top-10% penalty (matches actual metric)
            density_grid = sdf_density_grid(clamped, half_sizes, grid_x, grid_y, tau)
            flat_density = density_grid.flatten()
            k_density = max(1, int(0.10 * len(flat_density)))
            top_density, _ = torch.topk(flat_density, k_density)
            density_loss = top_density.mean()

            # Wirelength
            wl_loss = edge_wl(clamped, edges, edge_weights) / wl_norm

            # Overlap (ramp up with sqrt schedule for faster initial response)
            ov_w = self.overlap_weight * (0.05 + 0.95 * frac ** 0.5)
            ov_loss = overlap_penalty(clamped, half_sizes) / (cw * ch)

            # Density weight: higher early for spreading, lower late for WL
            dw = self.density_weight * (1.5 - 0.8 * frac)

            loss = wl_loss + dw * density_loss + ov_w * ov_loss
            loss.backward()
            optimizer.step()
            scheduler.step()

            with torch.no_grad():
                if step % 20 == 0 or step == self.n_iters - 1:
                    ov_val = overlap_penalty(clamped, half_sizes).item()
                    cost = wl_loss.item() + 0.1 * ov_val / (cw * ch)
                    if cost < best_cost:
                        best_cost = cost
                        best_pos = clamped.detach().clone()

        with torch.no_grad():
            final_pos = torch.where(movable.unsqueeze(1).expand_as(best_pos), best_pos, init_pos)
            final_pos = torch.stack([
                final_pos[:, 0].clamp(half_sizes[:, 0], cw - half_sizes[:, 0]),
                final_pos[:, 1].clamp(half_sizes[:, 1], ch - half_sizes[:, 1]),
            ], dim=1)

        pos_np = final_pos.numpy().astype(np.float64)
        sizes_np = sizes.numpy().astype(np.float64)
        legal_pos = greedy_legalize(pos_np, sizes_np, movable.numpy(), cw, ch)

        full_pos = benchmark.macro_positions.clone()
        full_pos[:n_hard] = torch.tensor(legal_pos, dtype=torch.float32)
        return finalize_placement(full_pos, benchmark, "SDF initializer")
